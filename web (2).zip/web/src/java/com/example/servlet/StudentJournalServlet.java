package com.example.servlet;

import com.example.model.Student;
import com.example.services.JournalService;
import com.example.model.Mark;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class StudentJournalServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Student student = (Student) request.getSession().getAttribute("student");

        if (student != null) {
            // Отримання журналу студента з бази даних або пам'яті
            List<Mark> marks = JournalService.getStudentJournal(student);
            request.setAttribute("marks", marks);
            request.getRequestDispatcher("student.jsp").forward(request, response);
        } else {
            response.sendRedirect("error.jsp");
        }
    }
}
