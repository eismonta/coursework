package com.example.services;

import com.example.model.Lesson;

import java.util.HashMap;
import java.util.Map;

public class LessonService {
    private static Map<Integer, Lesson> lessons = new HashMap<>();

    public static void addLesson(Lesson lesson) {
        lessons.put(lesson.getId(), lesson);
    }

    public static Lesson getLessonById(int lessonId) {
        return lessons.get(lessonId);
    }
}
