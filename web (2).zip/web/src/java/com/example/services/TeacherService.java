package com.example.services;

import com.example.model.Teacher;

import java.util.HashMap;
import java.util.Map;

public class TeacherService {
    private static Map<Integer, Teacher> teachers = new HashMap<>();

    public static void addTeacher(Teacher teacher) {
        teachers.put(teacher.getTeacherId(), teacher);
    }

    public static Teacher getTeacherById(int teacherId) {
        return teachers.get(teacherId);
    }
}
