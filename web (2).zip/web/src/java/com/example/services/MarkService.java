package com.example.services;

import com.example.model.Mark;

import java.util.ArrayList;
import java.util.List;

public class MarkService {
    private static List<Mark> marks = new ArrayList<>();

    public static void addMark(Mark mark) {
        marks.add(mark);
    }

    public static List<Mark> getAllMarks() {
        return marks;
    }
}
