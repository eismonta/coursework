package com.example.model;

public class Mark {
    private int id;             
    private Lesson lesson;      
    private Student student;    
    private int mark;          


    public Mark(int id, Lesson lesson, Student student, int mark) {
        this.id = id;
        this.lesson = lesson;
        this.student = student;
        this.mark = mark;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Lesson getLesson() {
        return lesson;
    }

    public void setLesson(Lesson lesson) {
        this.lesson = lesson;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }
}
