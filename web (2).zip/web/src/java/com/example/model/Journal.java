
package com.example.model;

import java.util.ArrayList;
import java.util.List;

public class Journal {
    private int id;             
    private Student student;   
    private Lesson lesson;      
    private final List<Mark> marks;   


    public Journal(int id, Student student, Lesson lesson) {
        this.id = id;
        this.student = student;
        this.lesson = lesson;
        this.marks = new ArrayList<>();
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Lesson getLesson() {
        return lesson;
    }

    public void setLesson(Lesson lesson) {
        this.lesson = lesson;
    }

    public List<Mark> getMarks() {
        return marks;
    }

    public void addMark(Mark mark) {
        marks.add(mark);
    }
}
