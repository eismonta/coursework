package com.example.services;

import com.example.model.Student;

import java.util.HashMap;
import java.util.Map;

public class StudentService {
    private static Map<Integer, Student> students = new HashMap<>();

    public static void addStudent(Student student) {
        students.put(student.getStudentId(), student);
    }

    public static Student getStudentById(int studentId) {
        return students.get(studentId);
    }
}
