package com.example.services;

import com.example.model.Mark;
import com.example.model.Student;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JournalService {
    private static Map<Integer, List<Mark>> journal = new HashMap<>();

    public static void addMarkToJournal(Mark mark) {
        int studentId = mark.getStudent().getStudentId();
        if (!journal.containsKey(studentId)) {
            journal.put(studentId, new ArrayList<>());
        }
        journal.get(studentId).add(mark);
    }

    public static List<Mark> getStudentJournal(Student student) {
        int studentId = student.getStudentId();
        return journal.getOrDefault(studentId, new ArrayList<>());
    }
}
