package com.example.model;

public class Teacher {
    private int teacherId;
    private String teacherName;
    private String teacherLogin;
    private String teacherPasswordHash;

    public Teacher(int teacherId, String teacherName, String teacherLogin, String teacherPasswordHash) {
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.teacherLogin = teacherLogin;
        this.teacherPasswordHash = teacherPasswordHash;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        this.teacherName = teacherName;
    }

    public String getTeacherLogin() {
        return teacherLogin;
    }

    public void setTeacherLogin(String teacherLogin) {
        this.teacherLogin = teacherLogin;
    }

    public String getTeacherPasswordHash() {
        return teacherPasswordHash;
    }

    public void setTeacherPasswordHash(String teacherPasswordHash) {
        this.teacherPasswordHash = teacherPasswordHash;
    }

    public String getTeacherInfo() {
        return "Teacher ID: " + teacherId + ", Name: " + teacherName + ", Login: " + teacherLogin;
    }
    
    @Override
public int hashCode() {
    final int prime = 17;
    int result = 1;
    result = prime * result + teacherId;
    return result;
}

@Override
public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    Teacher other = (Teacher) obj;
    if (teacherId != other.teacherId)
        return false;
    return true;
}

}
