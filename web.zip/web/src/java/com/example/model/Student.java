
package com.example.model;

public class Student {
    private int studentId;
    private String studentName;
    private String studentLogin;
    private String studentPasswordHash;

 
    public Student(int studentId, String studentName, String studentLogin, String studentPasswordHash) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentLogin = studentLogin;
        this.studentPasswordHash = studentPasswordHash;
    }


    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentLogin() {
        return studentLogin;
    }

    public void setStudentLogin(String studentLogin) {
        this.studentLogin = studentLogin;
    }

     public String getStudentPasswordHash() {
        return studentPasswordHash;
    }
     
     public void setStudentPasswordHash(String studentPasswordHash) {
        this.studentPasswordHash = studentPasswordHash;
    }
    
    public String getStudentInfo() {
        return "Student ID: " + studentId + ", Name: " + studentName + ", Login: " + studentLogin;
    }
    
@Override
public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + studentId;
    return result;
}

@Override
public boolean equals(Object obj) {
    if (this == obj)
        return true;
    if (obj == null)
        return false;
    if (getClass() != obj.getClass())
        return false;
    Student other = (Student) obj;
    if (studentId != other.studentId)
        return false;
    return true;
}

}
