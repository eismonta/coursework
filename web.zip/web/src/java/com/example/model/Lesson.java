package com.example.model;

import java.util.Date;

public class Lesson {
    private int id; 
    private String subject;
    private Date date;
    private Teacher teacher; 


    public Lesson(int id, String subject, Date date, Teacher teacher) {
        this.id = id;
        this.subject = subject;
        this.date = date;
        this.teacher = teacher;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
}
