package com.example.servlet;

import com.example.model.Lesson;
import com.example.model.Mark;
import com.example.model.Student;
import com.example.model.Teacher;
import com.example.services.JournalService;
import com.example.services.LessonService;
import com.example.services.StudentService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddMarkServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            int lessonId = Integer.parseInt(request.getParameter("lessonId"));
            int markValue = Integer.parseInt(request.getParameter("mark"));

            // Отримання об'єктів студента, заняття та вчителя з бази даних або пам'яті
            Student student = StudentService.getStudentById(studentId);
            Lesson lesson = LessonService.getLessonById(lessonId);
            Teacher teacher = (Teacher) request.getSession().getAttribute("teacher");

            // Перевірка наявності вчителя та даних про студента та заняття
            if (teacher != null && student != null && lesson != null) {
                // Створення об'єкта відмітки
                Mark mark = new Mark(0, lesson, student, markValue);
                // Додавання відмітки до журналу
                JournalService.addMarkToJournal(mark);
                response.sendRedirect("success.jsp");
            } else {
                response.sendRedirect("error.jsp");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("error.jsp");
        }
    }
}
